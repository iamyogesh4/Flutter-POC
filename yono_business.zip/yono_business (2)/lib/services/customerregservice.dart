import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

class Service {
//create the method  to save user

  Future<http.Response> saveUser(String name, String email, String username,
      String password, String address, String mobile) async {
    //creare URI

    var uri = Uri.parse("http://localhost:2000/corpcustomer/addcorpcust");

    //create Header

    Map<String, String> header = {"Content-type": "application/json"};

    //create body

    Map data = {
      'name': '$name',
      'email': '$email',
      'username': '$username',
      'password': '$password',
      'mobile': '$mobile',
      'address': '$address'
    };

    //convert the above data into Json
    var body = json.encode(data);

    var response = await http.post(uri, headers: header, body: body);

    //print the above response

    print("${response.body}");

    return response;
  }
}
