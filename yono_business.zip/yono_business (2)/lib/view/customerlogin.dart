import 'package:flutter/material.dart';
import 'package:http/http.dart';

import '../services/loginservice.dart';
import '../view/HomeScreen.dart';
import '../view/customerregmain.dart';

class CustomerLogin extends StatefulWidget {
  const CustomerLogin({super.key});

  @override
  State<CustomerLogin> createState() => _CustomerLoginState();
}

class _CustomerLoginState extends State<CustomerLogin> {
  //creating controller for fields

  TextEditingController usernameController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  LoginService service = LoginService();

  showAlertDialog(BuildContext context, String info) {
    // set up the buttons
    Widget okButton = ElevatedButton(
      child: const Text("OK"),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: const Text("YONO BUSINESS"),
      content: Text(
        info,
        style: const TextStyle(color: Colors.green),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  Future<void> login() async {
    Response res = await service.saveUser(
        usernameController.text, passwordController.text);

    String temp = res.body;

    String expectedMessage = 'Corporate Customer Login Succesfully::';

    if (temp == expectedMessage.trim()) {
      // If successful, navigate to the home screen
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => HomeScreen()),
      );

      showAlertDialog(context, "CORPORATE LOGIN successfully".toUpperCase());
    } else {
      showAlertDialog(context, "PLEASE ENTER VALID USERNAME AND PASSWORD");
      print('Login failed: $temp');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.all(20),
        child: ListView(
          children: [
            Container(
              height: 60,
              width: 100,
              color: Colors.blue,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Welcome To Yono Business',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.all(13.0),
                    child: Text(
                      "Corporate",
                      textAlign: TextAlign.left,
                      style: TextStyle(fontSize: 18, color: Colors.black),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.all(13.0),
                    child: Text(
                      "CMP Dealers/Agents",
                      textAlign: TextAlign.left,
                      style: TextStyle(fontSize: 18, color: Colors.black),
                    ),
                  ),
                ]),
            Divider(
              color: Colors.black,
              height: 20.0,
              thickness: 3.0,
              indent: 25.0,
              endIndent: 25.0,
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: TextField(
                controller: usernameController,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Username',
                ),
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: TextField(
                controller: passwordController,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Password',
                ),
              ),
            ),
            SizedBox(
              height: 5,
            ),
            ElevatedButton(
              onPressed: () {
                login();
              },
              child: Text('Login',
                  style: TextStyle(
                    fontSize: 25,
                  )),
            ),
            SizedBox(
              height: 150,
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const MyApp()),
                );
              },
              child: Text('Register',
                  style: TextStyle(
                    fontSize: 25,
                  )),
            ),
          ],
        ),
      ),
    );
  }
}
