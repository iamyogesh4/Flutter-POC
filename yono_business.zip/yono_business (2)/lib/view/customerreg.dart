import 'package:flutter/material.dart';
import '../main.dart';
import '../services/customerregservice.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  //creating controller for fields

  TextEditingController nameController = TextEditingController();

  TextEditingController emailController = TextEditingController();

  TextEditingController usernameController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  TextEditingController addressController = TextEditingController();

  TextEditingController mobileController = TextEditingController();

  //create the service class object

  Service service = Service();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.all(20),
        child: ListView(
          children: [
            Container(
              height: 60,
              width: 100,
              color: Colors.blue,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Welcome To Yono Business',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.all(13.0),
                    child: Text(
                      "Corporate",
                      textAlign: TextAlign.left,
                      style: TextStyle(fontSize: 18, color: Colors.black),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.all(13.0),
                    child: Text(
                      "CMP Dealers/Agents",
                      textAlign: TextAlign.left,
                      style: TextStyle(fontSize: 18, color: Colors.black),
                    ),
                  ),
                ]),
            Divider(
              color: Colors.black,
              height: 20.0,
              thickness: 3.0,
              indent: 25.0,
              endIndent: 25.0,
            ),
            Text('Name'),
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Enter Your Name',
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Text('Email'),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Enter Your Email',
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Text('Username'),
            TextField(
              controller: usernameController,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Username',
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Text('PassWord'),
            TextField(
              controller: passwordController,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Password ',
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Text('Address'),
            TextField(
              controller: addressController,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Enter Your Address',
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Text('Mobile Number'),
            TextField(
              controller: mobileController,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Enter Your Mobile Number',
              ),
            ),
            SizedBox(
              height: 5,
            ),
            ElevatedButton(
              onPressed: () {
                service.saveUser(
                    nameController.text,
                    emailController.text,
                    usernameController.text,
                    passwordController.text,
                    addressController.text,
                    mobileController.text);
              },
              child: Text('Register',
                  style: TextStyle(
                    fontSize: 25,
                  )),
            ),
            SizedBox(
              height: 150,
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const MyApp1()),
                );
              },
              child: Text('Back To Login',
                  style: TextStyle(
                    fontSize: 25,
                  )),
            ),
          ],
        ),
      ),
    );
  }
}
