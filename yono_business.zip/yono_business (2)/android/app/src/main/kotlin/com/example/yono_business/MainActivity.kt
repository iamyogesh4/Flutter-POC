package com.example.yono_business

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
