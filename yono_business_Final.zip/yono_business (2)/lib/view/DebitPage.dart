import 'package:flutter/material.dart';
import '../services/TransactionService.dart';


class DebitPage extends StatefulWidget {
  @override
  _DebitPageState createState() => _DebitPageState();
}

class _DebitPageState extends State<DebitPage> {
  TextEditingController toAccountNumberController = TextEditingController();
  TextEditingController fromAccountNumberController = TextEditingController();
  TextEditingController amountController = TextEditingController();

  TransactionService service = TransactionService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Debit Form"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextFormField(
              controller: fromAccountNumberController,
              decoration: InputDecoration(
                labelText: 'From Account',
                hintText: 'Enter From Account',
              ),
            ),
            SizedBox(height: 20),
            TextFormField(
              controller: toAccountNumberController,
              decoration: InputDecoration(
                labelText: 'To Account',
                hintText: 'Enter To Account',
              ),
            ),
            SizedBox(height: 20),
            TextFormField(
              controller: amountController,
              decoration: InputDecoration(
                labelText: 'Amount',
                hintText: 'Enter Amount',
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                int value = int.parse(amountController.text);
                // Action for proceed button
                service.debitTrasaction(
                  toAccountNumberController.text,
                  fromAccountNumberController.text,
                  value,
                );
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(
                    Colors.redAccent), // Background color of button
              ),
              child: Text('Proceed',
                  style:
                      TextStyle(color: Colors.white)), // Text color of button
            ),
          ],
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: DebitPage(),
  ));
}